Cuando te registras si pones tu correo electronico enviará un correo
a tu email cuando te registras a la newsletter