<h3 class="grid text">Bienvenido Invitado</h3>
<div class="container-fluid menu text-center p-3 my-4">
	<div class="container">
		<div class="row">
			<div class="col-md-12 ">
				<a href="index.php?ctl=home" class="p-3">INICIO</a>
				<a href="index.php?ctl=listarEjercicios" class="p-3">EJERCICIOS</a>
			</div>
		</div>
	</div>
</div>